import React from "react";
import {
    Img,
    BackgroundTop,
    DemoDIv,
    BackgroundTopHeading,
    SecImg,
    SecImgHolder,
    SecImgHolderHeading,
    SecImgSubHeading,
    SecImgHeading,
    ThirdFourth,
    ThirdFourthImgHolder,
    ThirdFourthImgHeading,
    ThirdFourthImgMainHeading,
    ThirdFourthImgSubHeading,
    IrcHolder,
    MainImg,
    ImageWrapper,
    GradientOverlay,
    Wrapper,
    BottomGradient,
    SecBottomGradient
} from './achievementStyled'
import RoverImg from "../../assest/IRC 25 Day 4 [DoPy]-11 (1).jpg";
import TeamRunner from "../../assest/team/IRC 25 Day 5 [DoPy] (35) (1).jpg"
import TeamEmerging from "../../assest/team/EmergingT.png"
import FirstPlace from "../../assest/team/firsterc.jpg"
//import TeamEmerging from "../../assest/team/emergingteam.jpg"
export const Achievement = () => {
    return (
        <IrcHolder>
            <BackgroundTop>
                <ImageWrapper>
                    <MainImg src={RoverImg} alt="background" />
                    <GradientOverlay />
                </ImageWrapper>

                <DemoDIv></DemoDIv>
                <BackgroundTopHeading>
                    Turning Ideas <br />
                    into Reality
                </BackgroundTopHeading>
            </BackgroundTop>
            <SecImg>
                <SecImgHolder>
                    <Wrapper>
                    <Img src={TeamRunner} alt="" />
                    <BottomGradient />
                    </Wrapper>
                    <SecImgHolderHeading>
                        <SecImgSubHeading>International Rover Challange'<span style={{ color: '#f16837' }}>25</span></SecImgSubHeading>
                        <SecImgHeading>RUNNER UP</SecImgHeading>
                    </SecImgHolderHeading>
                </SecImgHolder>
            </SecImg>
            <ThirdFourth>
                <div>
                    <ThirdFourthImgHolder>
                        <Img src={TeamEmerging} alt="" />
                        <BottomGradient />
                        {/* <DemoDIv></DemoDIv> */}
                    </ThirdFourthImgHolder>
                    <ThirdFourthImgHeading>
                        <ThirdFourthImgMainHeading> EMERGING TEAM <br /> OF THE YEAR </ThirdFourthImgMainHeading>
                        <ThirdFourthImgSubHeading>International Rover Challenge'<span style={{ color: '#f16837' }}>23</span></ThirdFourthImgSubHeading>
                    </ThirdFourthImgHeading>
                </div>
                <div>
                    <ThirdFourthImgHolder>
                        <Img src={FirstPlace} alt="" />
                        <BottomGradient />
                        {/* <DemoDIv></DemoDIv> */}
                    </ThirdFourthImgHolder>
                    <ThirdFourthImgHeading>
                        <ThirdFourthImgMainHeading> FIRST POSITION</ThirdFourthImgMainHeading>
                        <ThirdFourthImgSubHeading>ERC Hackathon'<span style={{ color: '#f16837' }}>24</span></ThirdFourthImgSubHeading>
                    </ThirdFourthImgHeading>
                </div>
            </ThirdFourth>
        </IrcHolder>
    )
}